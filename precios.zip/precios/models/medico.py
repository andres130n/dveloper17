# -*- coding:utf-8 -*-

from odoo import fields, models, api


class Medico(models.Model):
    _name = "medico"

    name = fields.Char()