#-*- coding:utf-8 -*-

{
    'name': 'Modulo de precios', 
    'version': '1.0', 
    'depends': [],
    'author': 'Andres Leon P',
    'category': 'Sales',  
    'website': 'https://d3veloperstudio.com/',
    'summary': 'Modulo creado por precios - por sucursales',
    'description': 'Modulo para data', 
    'data': [], 
}